# RonaldBible Android Project (v1.4 study tools update)

This is a recreated Android Studio project scaffold built around the enhanced web assets extracted from RonaldBible v1.1. It is **source code, not a prebuilt APK**. It has not yet been compiled or tested on a physical Android device in this environment.

## What's included
- Android WebView wrapper (`MainActivity.java`)
- Local app assets: `index.html`, `bible-data.js`, `preloaded-comm.js`
- App label and launcher icon
- Offline topical Bible study index with key passages for nine themes
- Curated Scripture cross-reference explorer
- Searchable introductory Bible dictionary
- Guided observation, interpretation, application and prayer worksheet with local saved studies
- Prayer journal stored locally on the device
- Chapter read-aloud using Android/WebView speech synthesis where supported
- Portable JSON backup and restore for bookmarks, highlights, notes, prayer entries, guided Bible studies, reading plans and preferences
- Reading streak tracking based on days a chapter is opened
- Gradle Android project configuration

## Build on a computer
1. Install Android Studio and a compatible JDK (JDK 17 recommended).
2. Open this folder in Android Studio.
3. Allow Gradle to sync and install Android SDK Platform 35 / Build Tools when prompted.
4. Test on an emulator or Android phone before release.
5. For a test APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. For publishing, create a signed release through **Build > Generate Signed Bundle / APK** and safely keep the signing key.

## Important limitations
- This project scaffold has not been compiled here; compatibility must be verified in Android Studio.
- Bible data and preloaded commentary assets are packaged locally, but some online commentary requests still call the original Base44 endpoints and need internet access. If those endpoints change or are disabled, online commentary may fail.
- Device-local saved notes, bookmarks, highlights and reading progress are not synced to another device. Clearing app data can remove them.
- No account system, automatic cloud backup/sync, recorded audio Bible, notifications, live AI provider integration, or additional licensed Bible translations are implemented by this scaffold yet. Cross-references are curated starter links rather than a comprehensive academic database; dictionary definitions are introductory summaries. The guided study worksheet is offline and does not claim to generate AI answers. Read-aloud uses device/browser speech synthesis and may be unavailable on some devices. The backup tool uses copy/paste JSON rather than a cloud account. AI explanations must be implemented through a secure backend; never place a provider secret in the APK or JavaScript assets.
- Before public distribution, verify the rights/license for all Bible translations and commentary content, privacy disclosures, and Play Store requirements.

## Security notes
The WebView only loads the bundled local page by default and disallows mixed content. Do not add broad JavaScript bridges or universal file URL access. If adding remote APIs, use HTTPS and validate requests and data carefully.

## Build from your Android phone using GitHub Actions
This project includes `.github/workflows/build-android.yml` so you can trigger a cloud build without installing Android Studio on your phone:
1. Create a GitHub repository and upload the extracted project folder contents (the `app`, `build.gradle`, `settings.gradle`, `gradle.properties`, and `.github` folder must be at repository root).
2. Open the repository on GitHub, choose **Actions**, then **Build RonaldBible APK**.
3. Tap **Run workflow** (or wait for the first push to `main` to trigger it).
4. When the run succeeds, open the run and download the `RonaldBible-debug-apk` artifact. Extract it on your phone and install the APK, allowing installs from that source if Android asks.
5. Treat this as a test build. Do not publish it until you've tested it and generated a properly signed release APK/AAB.

GitHub Actions is a cloud build route; it does not mean the project has already been built. The first workflow run may expose dependency or Android SDK issues that need fixing.
