# RonaldBible v1.3 — Study Tools Update

## Added
- Offline topical study guides for prayer, faith, forgiveness, peace, love, wisdom, marriage, the Holy Spirit and salvation.
- Prayer journal entries with title, reflection, answered-prayer flag, edit and delete.
- Chapter read-aloud using Web Speech API when the Android WebView supports it.
- Portable JSON backup and restore for saved verses, notes, highlights, prayer journal, reading plans, reading progress and preferences.
- Reading-day tracking and current streak display.
- App version bumped to 1.3 (versionCode 3).

## Notes
- Personal entries stay in local WebView storage. Clearing app data can remove them.
- Exported backups may contain private prayer entries and study notes; store them securely.
- Backup/restore has not been audited on every Android version. Test with a backup copy before relying on it.
- Read-aloud depends on device speech support and installed voice data.
- AI Bible study is intentionally not wired directly to a provider secret. Add it through a secure HTTPS backend.
- The Android APK has not been compiled or device-tested in this environment.
