# RonaldBible v1.4 — Study tools expansion

## Added
- Curated offline Scripture cross-reference explorer with reference filtering and one-tap navigation.
- Searchable introductory Bible dictionary with 20 terms.
- Guided Bible study worksheet for observation, interpretation, application, and prayer.
- Local storage for saved study worksheets, with delete and list views.
- Backup/restore now includes saved guided-study worksheets.
- Android version metadata updated to 1.4 / versionCode 4.

## Important limitations
- This is source code, not a compiled or device-tested APK.
- Cross-reference data is a curated starter set and is not exhaustive. Dictionary entries are introductory study aids.
- The guided worksheet is an offline structure, not a live AI assistant. A real AI assistant requires a secure backend and configured provider credentials.
- Existing commentary may still depend on the original online Base44 endpoints.
